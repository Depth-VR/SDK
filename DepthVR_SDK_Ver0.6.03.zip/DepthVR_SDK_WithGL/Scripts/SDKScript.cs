﻿using UnityEngine;
using System.Collections;
using System.Runtime.InteropServices;
using System.IO;
using System;
using DepthVR.SDK;
using DepthVR.Sensor;

public class SDKScript : MonoBehaviour {
	private SDKClass sdkClass=new SDKClass();
	#if UNITY_ANDROID
	private DepthvrSensorForAndroid depthSensorForAndroid=new DepthvrSensorForAndroid();
	#elif UNITY_IPHONE
	private DepthvrSensorForIos depthSensorForIos=new DepthvrSensorForIos();
	#else
	private DepthvrSensorForEditor depthsensorForEditor=new DepthvrSensorForEditor();
	#endif
	public float stadia;
	public string CameraLTag;
	public string CameraRTag;
	public bool Add_rotation_gameobject;
	public GameObject Rotation_gameobject;
	void Start () 
	{	
		sdkClass.stadia = stadia;
		stadia = sdkClass.stadia;

		sdkClass.Start(this);

		sdkClass.TagOfCameraL = CameraLTag;
		CameraLTag = sdkClass.TagOfCameraL;
		sdkClass.TagOfCameraR = CameraRTag;
		CameraRTag = sdkClass.TagOfCameraR;

		#if UNITY_ANDROID
		depthSensorForAndroid.Start(this);
		#elif UNITY_IPHONE
		depthSensorForIos.Start(this);
		#else
		depthsensorForEditor.Start(this);
		#endif
	}

	void OnGUI()
	{
		sdkClass.OnGUI ();
	}

	void Update () 
	{
		sdkClass.stadia=stadia;

		sdkClass.Update(this);
		#if UNITY_ANDROID
		depthSensorForAndroid.add_rotation_gameobject = Add_rotation_gameobject;
		depthSensorForAndroid.rotation_gameobject = Rotation_gameobject;
		depthSensorForAndroid.Update(this);
		#elif UNITY_IPHONE
		depthSensorForIos.add_rotation_gameobject = Add_rotation_gameobject;
		depthSensorForIos.rotation_gameobject = Rotation_gameobject;
		depthSensorForIos.Update(this);
		#else
		depthsensorForEditor.Update(this);
		#endif


	}

	void OnApplicationQuit()
	{
		#if UNITY_ANDROID
		depthSensorForAndroid.Quit ();
		#elif UNITY_IPHONE
		depthSensorForIos.Quit ();
		#else
		#endif

	}

	public void UpdateCameraProps()
	{
		sdkClass.UpdateCamearaProps ();
	}
	                          
}
